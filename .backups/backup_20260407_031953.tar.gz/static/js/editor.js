import { parseToBlocks } from './block-parser.js'
import { BlockRenderer } from './block-renderer.js'

const LANG_MAP = {
  py: 'python', js: 'javascript', ts: 'typescript', sh: 'bash', html: 'html',
  htm: 'html', css: 'css', json: 'json', md: 'markdown', yaml: 'yaml',
  yml: 'yaml', toml: 'toml', cfg: 'ini'
}

function mapLanguage(lang) {
  return LANG_MAP[lang] || lang || 'plaintext'
}

export const Editor = {
  ta: null,
  gutter: null,
  highlightLayer: null,
  currentLang: 'plaintext',
  _highlightTimer: null,
  _resizeHandler: null,
  _taInputHandler: null,
  _taScrollHandler: null,
  _taKeydownHandler: null,
  mode: 'text',
  blocks: [],
  _blockContainer: null,
  BLOCK_LANGS: new Set(['python', 'javascript', 'css']),

  init() {
    this.ta = document.getElementById('modalContent')
    this.gutter = document.getElementById('lineNumbers')
    if (!this.ta || !this.gutter) return

    this._createHighlightLayer()
    this._syncLayerStyles()

    this._taInputHandler = () => {
      this.updateGutter()
      this._scheduleHighlight()
    }
    this._taScrollHandler = () => this.syncScroll()
    this._taKeydownHandler = (e) => this.handleKeys(e)

    this.ta.addEventListener('input', this._taInputHandler)
    this.ta.addEventListener('scroll', this._taScrollHandler)
    this.ta.addEventListener('keydown', this._taKeydownHandler)

    this._resizeHandler = () => this._syncLayerStyles()
    window.addEventListener('resize', this._resizeHandler)

    this.updateGutter()
  },

  _syncLayerStyles() {
    if (!this.ta || !this.highlightLayer) return
    const styles = window.getComputedStyle(this.ta)
    const layer = this.highlightLayer

    // Only sync font metrics — position/size is handled by CSS
    // (top:0; left:36px; right:0; bottom:0) so the layer always
    // fills the editor-wrapper correctly regardless of layout timing.
    layer.style.fontFamily = styles.fontFamily
    layer.style.fontSize = styles.fontSize
    layer.style.lineHeight = styles.lineHeight
    layer.style.padding = styles.padding
    layer.style.whiteSpace = styles.whiteSpace
    layer.style.tabSize = styles.tabSize
    layer.style.letterSpacing = styles.letterSpacing
    layer.style.wordSpacing = styles.wordSpacing

    // Clear any leftover inline position/size from older code paths
    layer.style.position = ''
    layer.style.top = ''
    layer.style.left = ''
    layer.style.width = ''
    layer.style.height = ''
    layer.style.margin = ''

    this.ta.style.position = 'relative'
    this.ta.style.zIndex = '2'
    this.ta.style.caretColor = 'var(--syntax-cursor, #528bff)'
  },

  destroy() {
    if (this._highlightTimer) {
      clearTimeout(this._highlightTimer)
      this._highlightTimer = null
    }
    if (this._onLoadRAF) {
      cancelAnimationFrame(this._onLoadRAF)
      this._onLoadRAF = null
    }
    if (this._resizeHandler) {
      window.removeEventListener('resize', this._resizeHandler)
      this._resizeHandler = null
    }
    if (this.ta) {
      if (this._taInputHandler) this.ta.removeEventListener('input', this._taInputHandler)
      if (this._taScrollHandler) this.ta.removeEventListener('scroll', this._taScrollHandler)
      if (this._taKeydownHandler) this.ta.removeEventListener('keydown', this._taKeydownHandler)
      this._taInputHandler = null
      this._taScrollHandler = null
      this._taKeydownHandler = null
    }
    if (this.highlightLayer?.parentNode) {
      this.highlightLayer.parentNode.removeChild(this.highlightLayer)
      this.highlightLayer = null
    }
  },

  _createHighlightLayer() {
    if (this.highlightLayer) return
    const wrapper = document.getElementById('editorWrapper')
    if (!wrapper) return

    if (window.getComputedStyle(wrapper).position === 'static') {
      wrapper.style.position = 'relative'
    }

    this.highlightLayer = document.createElement('pre')
    this.highlightLayer.className = 'editor-highlight-layer'
    this.highlightLayer.setAttribute('aria-hidden', 'true')
    const code = document.createElement('code')
    this.highlightLayer.appendChild(code)
    wrapper.appendChild(this.highlightLayer)
  },

  _scheduleHighlight() {
    if (this._highlightTimer) clearTimeout(this._highlightTimer)
    this._highlightTimer = setTimeout(() => {
      this._doHighlight()
      if (this.highlightLayer) this.highlightLayer.style.visibility = ''
    }, 100)
  },

  _doHighlight() {
    if (!this.highlightLayer || !this.ta) return
    const code = this.highlightLayer.querySelector('code')
    if (!code) return

    const value = this.ta.value

    if (typeof hljs === 'undefined') {
      code.textContent = value
      this.highlightLayer.style.visibility = 'visible'
      this.ta.classList.remove('highlighting-on')
      this.ta.style.color = ''
      this.ta.style.background = ''
      this.ta.style.webkitTextFillColor = ''
      return
    }

    this.highlightLayer.style.visibility = ''

    let highlighted = false
    try {
      const result = hljs.highlight(value, { language: this.currentLang, ignoreIllegals: true })
      code.innerHTML = result.value
      code.className = `language-${this.currentLang} hljs`
      highlighted = true
    } catch {
      try {
        const result = hljs.highlightAuto(value)
        code.innerHTML = result.value
        code.className = `${result.language || ''} hljs`
        highlighted = true
      } catch {
        code.textContent = value
        this.ta.classList.remove('highlighting-on')
        this.ta.style.color = ''
        this.ta.style.background = ''
        this.ta.style.webkitTextFillColor = ''
        return
      }
    }

    if (highlighted) {
      this.ta.classList.add('highlighting-on')
      this.ta.style.color = 'transparent'
      this.ta.style.background = 'transparent'
      this.ta.style.webkitTextFillColor = 'transparent'
    }
    this.syncScroll()
  },

  setLanguage(lang) {
    this.currentLang = mapLanguage(lang)
    this._doHighlight()
  },

  updateGutter() {
    if (!this.ta || !this.gutter) return
    const text = this.ta.value
    const lineCount = text.length === 0 ? 1 : (text.match(/\n/g)?.length || 0) + 1
    if (lineCount <= 1) {
      this.gutter.textContent = '1'
    } else {
      this.gutter.textContent = Array.from({ length: lineCount }, (_, i) => i + 1).join('\n')
    }
    this._syncLayerStyles()
  },

  syncScroll() {
    if (!this.ta || !this.gutter) return
    this.gutter.scrollTop = this.ta.scrollTop
    if (this.highlightLayer) {
      this.highlightLayer.scrollTop = this.ta.scrollTop
      this.highlightLayer.scrollLeft = this.ta.scrollLeft
    }
  },

  handleKeys(e) {
    if (e.key === 'Tab') {
      e.preventDefault()
      this.insertAtCursor('    ')
      return
    }
    if (e.key === 'Enter') {
      e.preventDefault()
      const start = this.ta.selectionStart
      const val = this.ta.value
      const lineStart = val.lastIndexOf('\n', start - 1) + 1
      const currentLine = val.substring(lineStart, start)
      const indent = currentLine.match(/^\s*/)[0]
      const extraIndent = currentLine.trimEnd().endsWith(':') ||
                          currentLine.trimEnd().endsWith('{') ||
                          currentLine.trimEnd().endsWith('(') ||
                          currentLine.trimEnd().endsWith('[') ? '    ' : ''
      this.insertAtCursor('\n' + indent + extraIndent)
      return
    }
    if (e.key === 's' && e.ctrlKey) {
      e.preventDefault()
      document.getElementById('modalSave')?.click()
    }
  },

  insertAtCursor(text) {
    if (!this.ta) return
    this.ta.focus()
    const start = this.ta.selectionStart
    const end = this.ta.selectionEnd
    this.ta.setRangeText(text, start, end, 'end')
    this.ta.dispatchEvent(new Event('input', { bubbles: true }))
  },

  onLoad(lang, content) {
    if (this.mode === 'block') {
      this._exitBlockMode()
    }
    if (!this.ta) return

    // 1. Set content immediately (single source of truth)
    if (content !== undefined) this.ta.value = content

    // 2. Hide highlight layer during transition to prevent flash
    if (this.highlightLayer) this.highlightLayer.style.visibility = 'hidden'

    // 3. Update gutter + sync font metrics synchronously
    this.currentLang = mapLanguage(lang)
    this.blocks = []
    this.updateGutter()
    this.ta.scrollTop = 0
    this.ta.selectionStart = 0
    this.ta.selectionEnd = 0
    if (this.gutter) this.gutter.scrollTop = 0
    if (this.highlightLayer) this.highlightLayer.scrollTop = 0

    // 4. Render highlight in next animation frame — ensures browser
    //    has completed layout with the new content before we measure
    //    and paint. Prevents partial render / content flash.
    if (this._onLoadRAF) cancelAnimationFrame(this._onLoadRAF)
    this._onLoadRAF = requestAnimationFrame(() => {
      this._onLoadRAF = null
      this._doHighlight()
      // Show highlight layer only after content is fully rendered
      if (this.highlightLayer) this.highlightLayer.style.visibility = ''
    })
  },

  toggleMode() {
    try {
      if (this.mode === 'text') {
        this._enterBlockMode()
      } else {
        this._exitBlockMode()
      }
    } catch (err) {
      console.error('[Editor] toggleMode failed:', err)
      document.dispatchEvent(new CustomEvent('editor:blockmode-error', { detail: { error: err.message } }))
    }
  },

  _enterBlockMode() {
    const lang = this.currentLang
    if (!this.BLOCK_LANGS.has(lang)) {
      document.dispatchEvent(new CustomEvent('editor:blockmode-unsupported', { detail: { lang } }))
      return
    }

    const content = this.ta?.value ?? ''
    if (!content.trim()) {
      document.dispatchEvent(new CustomEvent('editor:blockmode-error', { detail: { error: 'No content to parse' } }))
      return
    }

    this.blocks = parseToBlocks(content, lang)

    if (!this.blocks || this.blocks.length === 0) {
      document.dispatchEvent(new CustomEvent('editor:blockmode-error', { detail: { error: 'Parser returned no blocks' } }))
      return
    }

    const container = document.getElementById('blockModeContainer')
    if (!container) {
      console.error('[Editor] blockModeContainer not found in DOM')
      return
    }
    this._blockContainer = container

    const wrapper = document.getElementById('editorWrapper')
    if (wrapper) wrapper.classList.add('hidden')
    container.classList.remove('hidden')

    BlockRenderer.render(this.blocks, lang, container)

    this.mode = 'block'
    this._updateToggleUI()
  },

  _exitBlockMode() {
    if (!this._blockContainer) return

    try {
      BlockRenderer.syncFromDOM(this.blocks)
      const text = BlockRenderer.blocksToText(this.blocks)
      if (this.ta) this.ta.value = text
    } catch (err) {
      console.error('[Editor] _exitBlockMode sync failed:', err)
    }

    const wrapper = document.getElementById('editorWrapper')
    if (wrapper) wrapper.classList.remove('hidden')
    if (this._blockContainer) this._blockContainer.classList.add('hidden')
    this._blockContainer = null

    this.mode = 'text'
    this._updateToggleUI()

    this.updateGutter()
    this._doHighlight()
  },

  syncBlocksToTextarea() {
    if (this.mode !== 'block' || !this.blocks.length) return
    BlockRenderer.syncFromDOM(this.blocks)
    const text = BlockRenderer.blocksToText(this.blocks)
    if (this.ta) this.ta.value = text
  },

  _updateToggleUI() {
    // Update ALL mode toggles (editor header + fullscreen bar)
    document.querySelectorAll('.block-mode-toggle').forEach(toggle => {
      toggle.querySelectorAll('button').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.mode === this.mode)
      })
    })
  }
}
